"""
API de Gerenciamento de Tarefas (To-Do List)
Desenvolvido com Flask
"""

from flask import Flask, request, jsonify
from datetime import datetime
from functools import wraps

# Inicialização do aplicativo Flask
app = Flask(__name__)

# Banco de dados em memória (simulação)
tarefas = []
contador_id = 1

# ============================================
# FUNÇÕES AUXILIARES
# ============================================

def gerar_id():
    """Gera um ID único para cada tarefa."""
    global contador_id
    novo_id = contador_id
    contador_id += 1
    return novo_id


def encontrar_tarefa(tarefa_id):
    """Encontra uma tarefa pelo ID."""
    for tarefa in tarefas:
        if tarefa['id'] == tarefa_id:
            return tarefa
    return None


def validar_dados_tarefa(dados):
    """Valida os dados de uma tarefa."""
    erros = []
    
    if 'titulo' not in dados or not dados['titulo'].strip():
        erros.append("O campo 'titulo' é obrigatório")
    
    if 'prioridade' in dados:
        prioridades_validas = ['baixa', 'media', 'alta']
        if dados['prioridade'] not in prioridades_validas:
            erros.append(f"Prioridade deve ser: {', '.join(prioridades_validas)}")
    
    return erros


def formatar_resposta(sucesso, mensagem=None, dados=None, codigo=200):
    """Formata a resposta da API de forma padronizada."""
    resposta = {
        'sucesso': sucesso,
        'timestamp': datetime.now().isoformat()
    }
    
    if mensagem:
        resposta['mensagem'] = mensagem
    
    if dados is not None:
        resposta['dados'] = dados
    
    return jsonify(resposta), codigo


def log_requisicao(func):
    """Decorator para registrar logs de requisições."""
    @wraps(func)
    def wrapper(*args, **kwargs):
        print(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {request.method} {request.path}")
        return func(*args, **kwargs)
    return wrapper


# ============================================
# ROTAS DA API
# ============================================

@app.route('/')
@log_requisicao
def pagina_inicial():
    """Rota inicial com informações da API."""
    info = {
        'nome': 'API de Tarefas',
        'versao': '1.0.0',
        'descricao': 'API REST para gerenciamento de tarefas pessoais',
        'endpoints': {
            'GET /': 'Informações da API',
            'GET /tarefas': 'Lista todas as tarefas',
            'GET /tarefas/<id>': 'Busca uma tarefa específica',
            'POST /tarefas': 'Cria uma nova tarefa',
            'PUT /tarefas/<id>': 'Atualiza uma tarefa existente',
            'DELETE /tarefas/<id>': 'Remove uma tarefa',
            'GET /tarefas/estatisticas': 'Estatísticas das tarefas',
            'PUT /tarefas/<id>/concluir': 'Marca tarefa como concluída',
            'GET /tarefas/filtrar': 'Filtra tarefas por status ou prioridade'
        }
    }
    return formatar_resposta(True, dados=info)


@app.route('/tarefas', methods=['GET'])
@log_requisicao
def listar_tarefas():
    """Lista todas as tarefas cadastradas."""
    return formatar_resposta(
        True,
        mensagem=f'{len(tarefas)} tarefa(s) encontrada(s)',
        dados=tarefas
    )


@app.route('/tarefas/<int:tarefa_id>', methods=['GET'])
@log_requisicao
def buscar_tarefa(tarefa_id):
    """Busca uma tarefa específica pelo ID."""
    tarefa = encontrar_tarefa(tarefa_id)
    
    if tarefa is None:
        return formatar_resposta(
            False,
            mensagem=f'Tarefa com ID {tarefa_id} não encontrada',
            codigo=404
        )
    
    return formatar_resposta(True, dados=tarefa)


@app.route('/tarefas', methods=['POST'])
@log_requisicao
def criar_tarefa():
    """Cria uma nova tarefa."""
    dados = request.get_json()
    
    if not dados:
        return formatar_resposta(
            False,
            mensagem='Dados JSON inválidos ou ausentes',
            codigo=400
        )
    
    # Validação dos dados
    erros = validar_dados_tarefa(dados)
    if erros:
        return formatar_resposta(False, mensagem=erros, codigo=400)
    
    # Criação da tarefa
    nova_tarefa = {
        'id': gerar_id(),
        'titulo': dados['titulo'].strip(),
        'descricao': dados.get('descricao', '').strip(),
        'prioridade': dados.get('prioridade', 'media'),
        'concluida': False,
        'criada_em': datetime.now().isoformat(),
        'atualizada_em': datetime.now().isoformat()
    }
    
    tarefas.append(nova_tarefa)
    
    return formatar_resposta(
        True,
        mensagem='Tarefa criada com sucesso',
        dados=nova_tarefa,
        codigo=201
    )


@app.route('/tarefas/<int:tarefa_id>', methods=['PUT'])
@log_requisicao
def atualizar_tarefa(tarefa_id):
    """Atualiza uma tarefa existente."""
    tarefa = encontrar_tarefa(tarefa_id)
    
    if tarefa is None:
        return formatar_resposta(
            False,
            mensagem=f'Tarefa com ID {tarefa_id} não encontrada',
            codigo=404
        )
    
    dados = request.get_json()
    
    if not dados:
        return formatar_resposta(
            False,
            mensagem='Dados JSON inválidos ou ausentes',
            codigo=400
        )
    
    # Atualização dos campos
    if 'titulo' in dados:
        tarefa['titulo'] = dados['titulo'].strip()
    
    if 'descricao' in dados:
        tarefa['descricao'] = dados['descricao'].strip()
    
    if 'prioridade' in dados:
        prioridades_validas = ['baixa', 'media', 'alta']
        if dados['prioridade'] in prioridades_validas:
            tarefa['prioridade'] = dados['prioridade']
    
    if 'concluida' in dados:
        tarefa['concluida'] = bool(dados['concluida'])
    
    tarefa['atualizada_em'] = datetime.now().isoformat()
    
    return formatar_resposta(
        True,
        mensagem='Tarefa atualizada com sucesso',
        dados=tarefa
    )


@app.route('/tarefas/<int:tarefa_id>', methods=['DELETE'])
@log_requisicao
def remover_tarefa(tarefa_id):
    """Remove uma tarefa pelo ID."""
    tarefa = encontrar_tarefa(tarefa_id)
    
    if tarefa is None:
        return formatar_resposta(
            False,
            mensagem=f'Tarefa com ID {tarefa_id} não encontrada',
            codigo=404
        )
    
    tarefas.remove(tarefa)
    
    return formatar_resposta(
        True,
        mensagem=f'Tarefa {tarefa_id} removida com sucesso'
    )


@app.route('/tarefas/<int:tarefa_id>/concluir', methods=['PUT'])
@log_requisicao
def concluir_tarefa(tarefa_id):
    """Marca uma tarefa como concluída."""
    tarefa = encontrar_tarefa(tarefa_id)
    
    if tarefa is None:
        return formatar_resposta(
            False,
            mensagem=f'Tarefa com ID {tarefa_id} não encontrada',
            codigo=404
        )
    
    tarefa['concluida'] = True
    tarefa['atualizada_em'] = datetime.now().isoformat()
    
    return formatar_resposta(
        True,
        mensagem='Tarefa marcada como concluída',
        dados=tarefa
    )


@app.route('/tarefas/estatisticas', methods=['GET'])
@log_requisicao
def obter_estatisticas():
    """Retorna estatísticas das tarefas."""
    total = len(tarefas)
    concluidas = sum(1 for t in tarefas if t['concluida'])
    pendentes = total - concluidas
    
    # Contagem por prioridade
    por_prioridade = {
        'alta': sum(1 for t in tarefas if t['prioridade'] == 'alta'),
        'media': sum(1 for t in tarefas if t['prioridade'] == 'media'),
        'baixa': sum(1 for t in tarefas if t['prioridade'] == 'baixa')
    }
    
    estatisticas = {
        'total': total,
        'concluidas': concluidas,
        'pendentes': pendentes,
        'taxa_conclusao': f'{(concluidas/total*100):.1f}%' if total > 0 else '0%',
        'por_prioridade': por_prioridade
    }
    
    return formatar_resposta(True, dados=estatisticas)


@app.route('/tarefas/filtrar', methods=['GET'])
@log_requisicao
def filtrar_tarefas():
    """Filtra tarefas por status ou prioridade."""
    status = request.args.get('status')  # 'concluida' ou 'pendente'
    prioridade = request.args.get('prioridade')  # 'baixa', 'media', 'alta'
    
    resultado = tarefas.copy()
    
    # Filtro por status
    if status == 'concluida':
        resultado = [t for t in resultado if t['concluida']]
    elif status == 'pendente':
        resultado = [t for t in resultado if not t['concluida']]
    
    # Filtro por prioridade
    if prioridade in ['baixa', 'media', 'alta']:
        resultado = [t for t in resultado if t['prioridade'] == prioridade]
    
    return formatar_resposta(
        True,
        mensagem=f'{len(resultado)} tarefa(s) encontrada(s)',
        dados=resultado
    )


# ============================================
# TRATAMENTO DE ERROS
# ============================================

@app.errorhandler(404)
def nao_encontrado(error):
    """Tratamento para rotas não encontradas."""
    return formatar_resposta(
        False,
        mensagem='Endpoint não encontrado',
        codigo=404
    )


@app.errorhandler(500)
def erro_interno(error):
    """Tratamento para erros internos do servidor."""
    return formatar_resposta(
        False,
        mensagem='Erro interno do servidor',
        codigo=500
    )


# ============================================
# EXECUÇÃO DO SERVIDOR
# ============================================

if __name__ == '__main__':
    print("=" * 50)
    print("  API de Gerenciamento de Tarefas")
    print("  Desenvolvido com Flask")
    print("=" * 50)
    print("\n  Servidor iniciado em: http://localhost:5000")
    print("  Pressione Ctrl+C para encerrar\n")
    
    app.run(debug=True, host='0.0.0.0', port=5000)
